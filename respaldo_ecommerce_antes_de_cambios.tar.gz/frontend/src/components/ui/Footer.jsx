// Pie de página
const Footer = () => (
<footer className="footer">
<div className="container">
<p>© {new Date().getFullYear()} MiAri Detalles. Todos los derechos reservados.</p>
</div>
</footer>
)


export default Footer